/* =========================================================
   保育共生地知識站 — site.js
   1) 首頁：讀 data/pages.json，依分類產生卡片
   2) 內容頁：依 pages.json 的順序產生「上一頁 / 下一頁」
   不要改欄位名稱（見 AGENTS.md 第 7、11 節）
   ========================================================= */

const CATEGORIES = [
  { id: "basics",   name: "認識概念", desc: "OECMs 是什麼、從哪裡來" },
  { id: "criteria", name: "認證條件", desc: "誰能申請、要符合哪些條件" },
  { id: "apply",    name: "申請流程", desc: "要準備什麼、怎麼審查" },
  { id: "manage",   name: "認證之後", desc: "效期、報告與權益" }
];

// 內容頁在 pages/ 底下，所以路徑要往上一層
const IN_PAGES = location.pathname.includes("/pages/");
const ROOT = IN_PAGES ? "../" : "./";

function sortPages(pages) {
  const catIndex = Object.fromEntries(CATEGORIES.map((c, i) => [c.id, i]));
  return [...pages].sort(
    (a, b) => (catIndex[a.category] - catIndex[b.category]) || (a.order - b.order)
  );
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, ch => (
    { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]
  ));
}

function renderHome(pages) {
  const root = document.getElementById("catalog");
  if (!root) return;
  root.innerHTML = CATEGORIES.map(cat => {
    const items = pages.filter(p => p.category === cat.id);
    const cards = items.length
      ? items.map(p => `
          <a class="card cat-${cat.id}" href="pages/${encodeURIComponent(p.slug)}.html">
            <h3>${escapeHtml(p.title)}</h3>
            <p>${escapeHtml(p.summary)}</p>
          </a>`).join("")
      : `<div class="card is-todo cat-${cat.id}"><h3>撰寫中</h3><p>這個分類還沒有頁面。</p></div>`;
    return `
      <section class="cat-section" id="${cat.id}">
        <div class="cat-head"><h2>${cat.name}</h2><p>${cat.desc}</p></div>
        <div class="card-grid">${cards}</div>
      </section>`;
  }).join("");

  const count = document.getElementById("page-count");
  if (count) count.textContent = pages.length;
}

function renderPager(pages) {
  const pager = document.querySelector(".pager[data-slug]");
  if (!pager) return;
  const i = pages.findIndex(p => p.slug === pager.dataset.slug);
  if (i < 0) return;
  const prev = pages[i - 1], next = pages[i + 1];
  pager.innerHTML =
    (prev ? `<a class="prev" href="${encodeURIComponent(prev.slug)}.html"><small>← 上一頁</small>${escapeHtml(prev.title)}</a>` : "") +
    (next ? `<a class="next" href="${encodeURIComponent(next.slug)}.html"><small>下一頁 →</small>${escapeHtml(next.title)}</a>` : "");
}

fetch(ROOT + "data/pages.json")
  .then(r => r.json())
  .then(data => {
    const pages = sortPages(data);
    renderHome(pages);
    renderPager(pages);
  })
  .catch(err => console.error("[oecm-wiki] 讀取 pages.json 失敗：", err));
